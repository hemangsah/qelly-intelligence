const ICON_PATHS={
  login:'<path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M14 4h5a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-5"/>',
  userPlus:'<path d="M15 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>',
  recovery:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
  session:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  shield:'<path d="M12 3 20 6v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6l8-3Z"/><path d="m9 12 2 2 4-4"/>',
  key:'<circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l3 3M14 9l2 2"/>',
  upload:'<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 20h16"/>',
  delivery:'<path d="M3 6h12v11H3zM15 10h3l3 3v4h-6"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
  status:'<circle cx="12" cy="12" r="9"/><path d="M8 12h8M12 8v8"/>',
  rotate:'<path d="M20 7v5h-5"/><path d="M4 17v-5h5"/><path d="M6.1 8a7 7 0 0 1 11.7-1L20 12M4 12l2.2 5a7 7 0 0 0 11.7-1"/>',
  quarantine:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="m9 9 6 6M15 9l-6 6"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  activity:'<path d="M3 12h4l2-7 4 14 2-7h6"/>',
  theme:'<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 0 1 0 18Z"/>',
  spark:'<path d="m12 3 1.7 4.3L18 9l-4.3 1.7L12 15l-1.7-4.3L6 9l4.3-1.7L12 3Z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z"/>',
  brand:'<path d="M6 4h8a4 4 0 0 1 0 8H6z"/><path d="M6 12h9a4 4 0 0 1 0 8H6z"/>',
  discovery:'<circle cx="11" cy="11" r="7"/><path d="m16 16 4 4M11 7v8M7 11h8"/>',
  ranking:'<path d="M5 19V9M12 19V5M19 19v-7"/><path d="M3 19h18"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  categories:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  venue:'<path d="M3 10 12 4l9 6"/><path d="M5 10v9M9 10v9M15 10v9M19 10v9M3 19h18"/>',
  dex:'<circle cx="8" cy="8" r="4"/><circle cx="16" cy="16" r="4"/><path d="m11 11 2 2M14 6h4v4M10 18H6v-4"/>',
  chart:'<path d="M4 19V5M4 19h16"/><path d="m7 15 4-4 3 2 5-6"/>',
  convert:'<path d="M7 7h11l-3-3M17 17H6l3 3"/>',
  news:'<path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/>',
  trust:'<path d="M12 3 20 6v6c0 5-3.4 8-8 9-4.6-1-8-4-8-9V6l8-3Z"/>',
  asset:'<circle cx="12" cy="12" r="8"/><path d="M9 9h6M9 12h6M9 15h4"/>',
  compare:'<path d="M4 7h13M14 4l3 3-3 3M20 17H7M10 14l-3 3 3 3"/>',
  market:'<path d="M4 18V9M10 18V5M16 18v-7M22 18V7"/>',
  watch:'<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
  alert:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/>',
  notification:'<path d="M4 5h16v14H4z"/><path d="m4 7 8 6 8-6"/>',
  screener:'<path d="M4 5h16M7 12h10M10 19h4"/><circle cx="8" cy="5" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="12" cy="19" r="2"/>',
  portfolio:'<path d="M4 8h16v11H4z"/><path d="M8 8V5h8v3M4 12h16"/>',
  research:'<path d="M5 4h11l3 3v13H5z"/><path d="M14 4v4h4M8 12h8M8 16h5"/>',
  onboarding:'<path d="M12 3v18M3 12h18"/><circle cx="12" cy="12" r="8"/>',
  schedule:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>',
  formula:'<path d="M7 4h10M11 4c-2 4-2 12-4 16M8 12h7"/>',
  import:'<path d="M4 4h10v16H4z"/><path d="M10 12h11M17 8l4 4-4 4"/>',
  history:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M12 7v5l4 2"/>',
  migration:'<path d="M4 6h12M12 3l4 3-4 3M20 18H8M12 15l-4 3 4 3"/>',
  identity:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  data:'<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7"/>',
  instrument:'<path d="M4 18 10 6l4 8 2-4 4 8"/>',
  stream:'<path d="M4 8h10M10 4l4 4-4 4M20 16H10M14 12l-4 4 4 4"/>',
  evidence:'<path d="M5 4h14v16H5z"/><path d="m8 12 2 2 5-5M8 17h8"/>',
  security:'<path d="M7 10V7a5 5 0 0 1 10 0v3"/><rect x="4" y="10" width="16" height="11" rx="2"/>'
};
const icon=(name)=>`<svg class="q-route-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${ICON_PATHS[name]??ICON_PATHS.status}</svg>`;

const routes = [
  { section:'Access', route:'auth-login', label:'Secure Login', icon:icon('login'), meta:'A1', public:true, anonymousOnly:true },
  { section:'Access', route:'auth-register', label:'Create Organization', icon:icon('userPlus'), meta:'A1', public:true, anonymousOnly:true },
  { section:'Access', route:'auth-recovery', label:'Recover Account', icon:icon('recovery'), meta:'A4', public:true, anonymousOnly:true },
  { section:'Account', route:'account-session', label:'Session Center', icon:icon('session'), meta:'A1' },
  { section:'Account', route:'security-setup', label:'MFA Setup', icon:icon('shield'), meta:'A2' },
  { section:'Account', route:'passkey-center', label:'Passkey Center', icon:icon('key'), meta:'A3' },
  { section:'Account', route:'account-recovery', label:'Recovery Controls', icon:icon('recovery'), meta:'A3' },
  { section:'Operations', route:'secure-import-vault', label:'Secure Import Vault', icon:icon('upload'), meta:'A2' },
  { section:'Operations', route:'delivery-operations', label:'Delivery Operations', icon:icon('delivery'), meta:'A3' },
  { section:'Operations', route:'platform-readiness', label:'Platform Readiness', icon:icon('status'), meta:'A4' },
  { section:'Security', route:'secret-rotation', label:'Secret Rotation', icon:icon('rotate'), meta:'A5' },
  { section:'Operations', route:'quarantine-review', label:'Quarantine Review', icon:icon('quarantine'), meta:'A5' },
  { section:'Operations', route:'staging-assurance', label:'Staging Assurance', icon:icon('check'), meta:'A5' },
  { section:'Live', route:'live-markets', label:'Live Market Command', icon:icon('activity'), meta:'P22' },
  { section:'Experience', route:'theme-personas', label:'Theme Personas', icon:icon('theme'), meta:'P22' },
  { section:'Experience', route:'feature-universe', label:'Feature Universe', icon:icon('spark'), meta:'P22' , public:true },
  { section:'Company', route:'about-qelly', label:'About Qelly', icon:icon('brand'), meta:'P22' , public:true },
  { section:'Discover', route:'discovery-hub', label:'Discovery Overview', icon:icon('discovery'), meta:'W5' },
  { section:'Discover', route:'asset-rankings', label:'Asset Rankings', icon:icon('ranking'), meta:'W5' , public:true },
  { section:'Discover', route:'search', label:'Universal Search', icon:icon('search'), meta:'W5' },
  { section:'Discover', route:'categories', label:'Categories', icon:icon('categories'), meta:'W5' },
  { section:'Discover', route:'venues', label:'Venues', icon:icon('venue'), meta:'W5' },
  { section:'Discover', route:'dex-discovery', label:'DEX Discovery', icon:icon('dex'), meta:'W5' },
  { section:'Discover', route:'global-charts', label:'Global Charts', icon:icon('chart'), meta:'W5' },
  { section:'Discover', route:'converter', label:'Converter', icon:icon('convert'), meta:'W5' },
  { section:'Discover', route:'news-research', label:'News & Research', icon:icon('news'), meta:'W5' },
  { section:'Discover', route:'trust-center', label:'Trust Center', icon:icon('trust'), meta:'W5' },
  { section:'Intelligence', route:'asset-intelligence', label:'Asset Intelligence', icon:icon('asset'), meta:'W6' },
  { section:'Intelligence', route:'advanced-chart', label:'Advanced Chart Studio', icon:icon('chart'), meta:'W6' },
  { section:'Intelligence', route:'fundamentals-estimates', label:'Fundamentals & Estimates', icon:icon('research'), meta:'W6' },
  { section:'Intelligence', route:'filing-workspace', label:'Filing Workspace', icon:icon('research'), meta:'W6' },
  { section:'Intelligence', route:'event-calendar', label:'Event Calendar', icon:icon('schedule'), meta:'W6' },
  { section:'Intelligence', route:'comparison-lab', label:'Comparison Lab', icon:icon('compare'), meta:'W6' },
  { section:'Intelligence', route:'market', label:'Market Overview', icon:icon('market'), meta:'W1' , public:true },
  { section:'Intelligence', route:'rankings', label:'Legacy Rankings', icon:icon('ranking'), meta:'W1' },
  { section:'Workspace', route:'asset', label:'Asset Dossier', icon:icon('asset'), meta:'W1' , public:true },
  { section:'Workspace', route:'watchlist', label:'Watchlists', icon:icon('watch'), meta:'W7' },
  { section:'Workspace', route:'alert-center', label:'Alert Rules', icon:icon('alert'), meta:'W7' },
  { section:'Workspace', route:'notification-center', label:'Notifications', icon:icon('notification'), meta:'W7' },
  { section:'Workspace', route:'screener-lab', label:'Screener Lab', icon:icon('screener'), meta:'W7' },
  { section:'Workspace', route:'portfolio-analytics', label:'Portfolio Analytics', icon:icon('portfolio'), meta:'W7' },
  { section:'Workspace', route:'research-workspace', label:'Research Workspace', icon:icon('research'), meta:'W7' },
  { section:'Workspace', route:'onboarding', label:'Guided Onboarding', icon:icon('onboarding'), meta:'P21' },
  { section:'Workspace', route:'notification-schedules', label:'Notification Schedules', icon:icon('schedule'), meta:'P21' },
  { section:'Workspace', route:'formula-screener', label:'Formula Screener', icon:icon('formula'), meta:'P21' },
  { section:'Workspace', route:'portfolio-attribution', label:'Portfolio Attribution', icon:icon('portfolio'), meta:'P21' },
  { section:'Workspace', route:'import-center', label:'Import Center', icon:icon('import'), meta:'P21' },
  { section:'Workspace', route:'research-history', label:'Research History', icon:icon('history'), meta:'P21' },
  { section:'Operations', route:'migration-center', label:'Migration Center', icon:icon('migration'), meta:'P21' },
  { section:'Platform', route:'theme-lab', label:'Theme Laboratory', icon:icon('theme'), meta:'W1' },
  { section:'Control', route:'identity-access', label:'Identity & Access', icon:icon('identity'), meta:'W2' },
  { section:'Control', route:'data-mesh', label:'Provider Runtime', icon:icon('data'), meta:'W3' },
  { section:'Control', route:'instrument-master', label:'Instrument Master', icon:icon('instrument'), meta:'W3' },
  { section:'Data Plane', route:'timeseries-lab', label:'Time Series Lab', icon:icon('chart'), meta:'W4' },
  { section:'Data Plane', route:'stream-operations', label:'Stream Operations', icon:icon('stream'), meta:'W4' },
  { section:'Operations', route:'observability', label:'Observability Center', icon:icon('activity'), meta:'W4' },
  { section:'Evidence', route:'decision-provenance', label:'Decision Provenance', icon:icon('evidence'), meta:'Scope A' },
  { section:'Evidence', route:'security-evidence', label:'Security Evidence', icon:icon('security'), meta:'W2' },
  { section:'Detail', route:'category-detail', label:'Category Detail', icon:icon('categories'), meta:'W5', hidden:true },
  { section:'Detail', route:'venue-detail', label:'Venue Detail', icon:icon('venue'), meta:'W5', hidden:true },
  { section:'Detail', route:'research-article', label:'Research Article', icon:icon('research'), meta:'W5', hidden:true }
];

export const productDomains = [
  { id:'home', label:'Home', shortLabel:'Home', icon:icon('brand'), defaultRoute:'feature-universe', destinations:['Home','Product','Company','Learning'] },
  { id:'markets', label:'Markets', shortLabel:'Markets', icon:icon('market'), defaultRoute:'market', destinations:['Markets','Discovery','Assets','Derivatives','Exchanges','Charts','Screener'] },
  { id:'research', label:'Research', shortLabel:'Research', icon:icon('research'), defaultRoute:'news-research', destinations:['Research','News','Events','Learning'] },
  { id:'workspaces', label:'Workspaces', shortLabel:'Work', icon:icon('portfolio'), defaultRoute:'watchlist', destinations:['Portfolio','Watchlists','Alerts','Workspaces','Settings'] },
  { id:'evidence', label:'Evidence', shortLabel:'Evidence', icon:icon('evidence'), defaultRoute:'decision-provenance', destinations:['Decision Provenance','Evidence','Trust'] },
  { id:'data', label:'Data plane', shortLabel:'Data', icon:icon('data'), defaultRoute:'data-mesh', destinations:['Data Sources','Developer/API','Operations'] },
  { id:'operations', label:'Operations', shortLabel:'Ops', icon:icon('status'), defaultRoute:'platform-readiness', destinations:['Operations','Security','Trust'] },
  { id:'account', label:'Account', shortLabel:'Account', icon:icon('identity'), defaultRoute:'account-session', destinations:['Settings','Workspaces','Team'] },
  { id:'experience', label:'Experience', shortLabel:'Mode', icon:icon('theme'), defaultRoute:'theme-personas', destinations:['Personas','Navigation','Accessibility'] }
];

const explicitDomain = {
  'feature-universe':'home','about-qelly':'home',
  market:'markets',rankings:'markets','asset-rankings':'markets','discovery-hub':'markets',search:'markets',categories:'markets','category-detail':'markets',venues:'markets','venue-detail':'markets','dex-discovery':'markets','global-charts':'markets',converter:'markets',asset:'markets','asset-intelligence':'markets','advanced-chart':'markets','live-markets':'markets',
  'news-research':'research','research-article':'research','research-workspace':'research','research-history':'research','filing-workspace':'research','fundamentals-estimates':'research','event-calendar':'research','comparison-lab':'research',
  watchlist:'workspaces','alert-center':'workspaces','notification-center':'workspaces','notification-schedules':'workspaces','screener-lab':'workspaces','formula-screener':'workspaces','portfolio-analytics':'workspaces','portfolio-attribution':'workspaces',onboarding:'workspaces','import-center':'workspaces',
  'decision-provenance':'evidence','security-evidence':'evidence','trust-center':'evidence',
  'data-mesh':'data','instrument-master':'data','timeseries-lab':'data','stream-operations':'data',
  'secure-import-vault':'operations','delivery-operations':'operations','platform-readiness':'operations','secret-rotation':'operations','quarantine-review':'operations','staging-assurance':'operations','migration-center':'operations',observability:'operations','identity-access':'operations',
  'auth-login':'account','auth-register':'account','auth-recovery':'account','account-session':'account','security-setup':'account','passkey-center':'account','account-recovery':'account',
  'theme-personas':'experience','theme-lab':'experience'
};

const publicStoryRoutes = new Set(['feature-universe','about-qelly','theme-personas']);
const researchRoutes = new Set(['news-research','research-article','research-workspace','research-history','filing-workspace','fundamentals-estimates','event-calendar','trust-center','decision-provenance']);
const operationalRoutes = new Set(['secure-import-vault','delivery-operations','platform-readiness','secret-rotation','quarantine-review','staging-assurance','migration-center','observability','identity-access','data-mesh','instrument-master','timeseries-lab','stream-operations','security-evidence','theme-lab']);
const accessRoutes = new Set(['auth-login','auth-register','auth-recovery','account-session','security-setup','passkey-center','account-recovery']);

function routeKind(route){
  if(publicStoryRoutes.has(route))return 'public-story';
  if(researchRoutes.has(route))return 'research';
  if(operationalRoutes.has(route))return 'operational';
  if(accessRoutes.has(route))return 'access';
  return 'analytical';
}

export const routeDefinitions = routes.map((item)=>({
  ...item,
  domain:explicitDomain[item.route]??'markets',
  kind:routeKind(item.route)
}));

export function domainForRoute(route){
  return routeDefinitions.find((item)=>item.route===route)?.domain??'markets';
}
