# Delivery font sanitization

The review screenshots and automated browser evidence were generated from the exact repository build with the approved self-hosted IBM Plex Sans Variable file. The downloadable review ZIP omits distributable font binaries. The compiled-preview copy has its font preload and binary source references removed and falls back to the documented system stack. The IBM Plex license text and source-governance evidence remain included.
